import { serve } from "https://deno.land";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { amount, phone, riderName } = await req.json();

    const consumerKey = Deno.env.get("MPESA_CONSUMER_KEY")!;
    const consumerSecret = Deno.env.get("MPESA_CONSUMER_SECRET")!;
    const shortcode = Deno.env.get("MPESA_SHORTCODE")!;
    const passkey = Deno.env.get("MPESA_PASSKEY")!;
    
    const mpesaBaseUrl = "https://safaricom.co.ke"; 

    // 1. GENERATE AN ACTIVE OAUTH ACCESS TOKEN
    const authCredentials = btoa(`${consumerKey}:${consumerSecret}`);
    const tokenResponse = await fetch(`${mpesaBaseUrl}/oauth/v1/generate?grant_type=client_credentials`, {
      method: "GET",
      headers: { "Authorization": `Basic ${authCredentials}` },
    });
    
    if (!tokenResponse.ok) {
      throw new Error(`Safaricom Auth Rejected. Verify Consumer Keys inside your vault.`);
    }
    const { access_token } = await tokenResponse.json();

    // 2. COMPILE SECURITY TIMESTAMP & PASSWORD KEYS (Africa/Nairobi Time)
    const timestamp = new Date().toLocaleString("en-US", { timeZone: "Africa/Nairobi" })
      .replace(/[^0-9]/g, "").slice(0, 14);
    const password = btoa(`${shortcode}${passkey}${timestamp}`);

    // 3. ASSEMBLE THE OUTBOUND LIPA NA M-PESA STK PUSH DATA MATRIX
    const stkPayload = {
      BusinessShortCode: shortcode,
      Password: password,
      Timestamp: timestamp,
      TransactionType: "CustomerBuyGoodsOnline", // Hardened routing for Till / Pochi
      Amount: Math.round(amount),
      PartyA: phone, 
      PartyB: shortcode,
      PhoneNumber: phone,
      CallBackURL: `https://supabase.co`, 
      AccountReference: `FastDrop`,
      TransactionDesc: `Campus delivery payment handled by rider: ${riderName}`,
    };

    console.log(`📡 Relaying payload up to Safaricom channels for wallet ${shortcode}, amount: KSh ${amount}`);

    const darajaStkResponse = await fetch(`${mpesaBaseUrl}/mpesa/stkpush/v1/processrequest`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${access_token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(stkPayload),
    });

    const stkResultData = await darajaStkResponse.json();

    return new Response(JSON.stringify(stkResultData), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error: any) {
    console.error("❌ M-Pesa Edge Function Crash Exception:", error.message);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
